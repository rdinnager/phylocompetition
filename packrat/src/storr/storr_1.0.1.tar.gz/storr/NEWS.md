## storr 1.0.1 (2016-05-10)

* Updated to work with recent testthat (>= 1.0.0)
* Limited support for writing out very large serialised objects (rds)

## storr 1.0.0 (2016-01-19)

* Initial CRAN release
